# Belle Peau
## Modelo Vista Controlador
### Estructura de la página Belle Peau

- controllers
- models
- public
- views

# Comandos GitHub

### git pull origin nameRama
- Este comando nos permite traer los archivos de reporsitorio remoto a mi sitio local.

### git branch nameRama
- Crea una nueva Rama

### git checkout nameRama
- Verifica que estes trabajando con la rama correcta

### git add . OR git add nameFile
- Agrega los creados o modificados.

### git commit -m "mensaje"
- Coloca un mensaje identificativo a los archivos previamente agregados.

### git push -u origin nameRama
- push - origin sube los commits a la rama indicada.