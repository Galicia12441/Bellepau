function redireccionar(){
    window.location.href = "https://fhjosemanuel.github.io/bellepeau/views/products/index.html";
}